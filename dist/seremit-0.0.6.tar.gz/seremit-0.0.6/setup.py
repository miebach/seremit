#from distutils.core import setup, find_packages
from setuptools import setup, find_packages

setup(
  name = "seremit",
  version = "0.0.6",
  packages=find_packages(),
  author = "Kurt Miebach",
  author_email = "kwmiebach@gmail.com",
)


