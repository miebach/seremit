#!/usr/bin/python
STD_PARAMS = "-avz --stats" + \
  " --timeout=320" + \
  " --numeric-ids" + \
  " --partial" + \
  " --progress"
  #" --skip-compress=rar/gz/zip/z/rpm/deb/iso/bz2/tgz/tbz/7z/" + \
  #                 "mp3/mp4/mov/avi/ogg/jpg/jpeg/gif/png/msi"
                             
             

