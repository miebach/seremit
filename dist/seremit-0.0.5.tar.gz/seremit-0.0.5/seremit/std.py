#!/usr/bin/python
STD_PARAMS = "-avz --stats" + \
  " --timeout=320" + \
  " --numeric-ids" + \
  " --partial" + \
  " --progress"

  #" --skip-compress=rar/gz/zip/z/rpm/deb/iso/bz2/t[gb]z/7z/" + \
  #               "mp[34]/mov/avi/ogg/jpg/jpeg/gif/png/msi" + \
                             
             

